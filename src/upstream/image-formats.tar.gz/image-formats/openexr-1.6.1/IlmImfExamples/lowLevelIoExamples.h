
void lowLevelIoExamples ();

