
void rgbaInterfaceTiledExamples ();

